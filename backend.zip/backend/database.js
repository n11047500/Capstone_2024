const mysql = require('mysql2');

let connection;

function handleDisconnect() {
  connection = mysql.createConnection({
    host: process.env.DB_HOST,
    port: process.env.DB_PORT,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    ssl: {
      rejectUnauthorized: false
    }
  });

//  connection.connect((err) => {
//    if (err) {
//      console.error('Error connecting to the database:', err.stack);
//      setTimeout(handleDisconnect, 2000); // Retry connection after 2 seconds
//    } else {
//      console.log('Connected to the database.');
//    }
//  });

  connection.on('error', (err) => {
    console.error('Database error:', err);
    if (err.code === 'PROTOCOL_CONNECTION_LOST') {
      console.error('Database connection lost. Reconnecting...');
      handleDisconnect(); // Reconnect on connection lost
    } else {
      throw err; // Re-throw other errors
    }
  });
}

handleDisconnect();

module.exports = connection;
